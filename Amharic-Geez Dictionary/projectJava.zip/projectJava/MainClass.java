public class MainClass {
    public static void main(String[] args) {
        DictUI newDictUI = new DictUI();
        newDictUI.setVisible(true);
    }
}
